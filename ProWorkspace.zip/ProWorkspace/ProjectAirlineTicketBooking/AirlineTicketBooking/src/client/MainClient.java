package com.capgemini.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;
import com.capgemini.util.JdbcUtil;

public class MainClient {

	private static final Logger mylogger=Logger.getLogger(MainClient.class);
	  
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("MainClient Statred");
		ArrayList <BusBean>BusList=new ArrayList<BusBean>(); 
		BusService busService= new BusServiceImpl();   
		BusList=busService.retrieveBusDetails();       //retrieves all bus Details
		System.out.println("Bus Details are shown below:");
		System.out.println();
		for(BusBean busDetail:BusList)
		{
			System.out.println(busDetail);  //displays all bus Details retrieved from database
		}
		System.out.println();
		Menu();

	}
	
	public static void Menu()
	{
		System.out.println("Menu:");
		System.out.println("1.Book Ticket");
		System.out.println("2.Exit");
		System.out.println("Enter your choice:");
		Scanner sc=new Scanner(System.in);
		int key=sc.nextInt();
		Menuchioce(key);
	}

	private static void Menuchioce(int key) {
		BusServiceImpl busService= new BusServiceImpl(); 
		
		switch (key) {
		case 1:
			System.out.println("Enter Customer Id ");
			String pattern="^[A-Z]{1}[0-9]{6}$";
			Scanner sc1=new Scanner(System.in);
			String custId=sc1.nextLine();
			BookingBean bookTick=new BookingBean();
			try {
				 busService.validatecustId(pattern,custId);
				 bookTick.setCustId(custId);
			
			} catch (BookingException e1) {
				System.out.println(e1);
				Menu();
			}
			
			System.out.println("Enter Bus Id ");
			String pattern1="^[1-9]{1}$";
			Scanner sc=new Scanner(System.in);
			String busId=sc.next();
			int bus_id=Integer.parseInt(busId);
			try {
				 busService.validatebusId(pattern1,busId); 
				 bookTick.setBusId(bus_id);
			} catch (BookingException e1) {
				System.out.println(e1);
				Menu();
			}
			
			System.out.println("Enter number of seats to be booked");
			String pattern2="^[1-9]{1}$";
			Scanner sc2=new Scanner(System.in);
			String noOfSeats=sc2.next();
			int noofseat=Integer.parseInt(noOfSeats);
			try {
				 busService.validateNoofSeat(pattern2,noOfSeats,busId); 
				 bookTick.setNoOfSeat(noofseat);
				 
				 //System.out.println(bookTick.getBusId()+" "+bookTick.getBusId()+" "+bookTick.getNoOfSeat());
				 
				 
				 busService.bookTicket(bookTick);
				 
			} catch (BookingException e1) {
				System.out.println(e1);
				Menu();
			}
			
			
			break;

		case 2:
			break;
		}
		
	}

}
