package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.JdbcUtil;


public class BusDaoImpl implements BusDao{

	Connection conn;
	PreparedStatement pst;
	private static final Logger mylogger=
			Logger.getLogger(BusDaoImpl.class);
	
	public ArrayList<BusBean> retrieveBusDetails() {
		try {
			conn=JdbcUtil.getConnection();
		} catch (BookingException e2) {
			e2.printStackTrace();
		}
		String query="Select * from BusDetails";
		ArrayList <BusBean>BusList=new ArrayList<BusBean>();

		try {
			pst=conn.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				int busId=rs.getInt("busId"); //retrieve bus details using prepareStatement
				String busType=rs.getString("busType");
				Date dateOfJourney=rs.getDate("dateOfJourney");
				String fromStop=rs.getString("fromStop");
				String toStop=rs.getString("toStop");
				int availableSeats=rs.getInt("availableSeats");
				int fare=rs.getInt("fare");
				
				BusBean busBean=new BusBean();      //store input data row into BusBean object
				busBean.setBusId(busId);
				busBean.setBusType(busType);
				busBean.setFromStop(fromStop);
				busBean.setToStop(toStop);
				busBean.setAvailableSeats(availableSeats);
				busBean.setFare(fare);
				busBean.setDateOfJourney(dateOfJourney);
				
				BusList.add(busBean);
				mylogger.info("Bus Details displayed ");
			}
		} catch (SQLException e) {
			System.out.println("SQLException while displaying bus details");
			//e.printStackTrace();
			try {
				throw new BookingException("BusDetails not Retrieved");
				
			} catch (BookingException e1) {
				e1.printStackTrace();
				mylogger.error("Bus Details not displayed");
			}     //throw user defined exception
		}finally
		{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		        return BusList;        //return BusDetails
	}

	
	
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		conn=JdbcUtil.getConnection();
		
		int bookingid=getBookingId();
		System.out.println("booking id is"+bookingid);
		
		
	    int rec;
	    String custid=bookingBean.getCustId();
	    int busid=bookingBean.getBusId();
	    int seat=bookingBean.getNoOfSeat();
	    System.out.println(custid+" "+busid+" "+seat);
		String query="INSERT into BookingDetails VALUES (?,?,?,?)";
		try {
			System.out.println("in try");
			pst=conn.prepareStatement(query);
			pst.setInt(1,bookingid);
			pst.setString(2,custid);
			pst.setInt(3,busid);
			pst.setInt(4,seat);
			rec=pst.executeUpdate();
			System.out.println("updated"+rec);
			if(rec!=0)
			{
				System.out.println("Thank you.Your booking Id is"+bookingid);
				mylogger.info("Ticked booked "+bookingid);
				updateSeatsAvailable(busid,bookingBean.getNoOfSeat());
				return 1;			
			}
			
		} catch (SQLException e) {
				//e.printStackTrace();
			System.out.println(e);
			mylogger.error("Ticked not booked");
			throw new BookingException("Sorry No Seats Available"); 
			
		}
		return 0;
		
	}
	
	public boolean updateSeatsAvailable(int busId, int noOfSeats)throws BookingException {
		conn=JdbcUtil.getConnection();
		String query="UPDATE BusDetails set availableSeats=availableSeats-? where busId=?";
		int rec=0;
		try {
			pst=conn.prepareStatement(query);
			pst.setInt(1, noOfSeats);
			pst.setInt(2, busId);
			rec=pst.executeUpdate();
			if(rec>0)
				{
				System.out.println("BusDetails Updated");
				mylogger.info("BusDetails seats Updated "+busId);

				return true;
				}
			
		} catch (SQLException e) {
			System.out.println(e);
			mylogger.error("BusDetails seats not Updated ");
			throw new BookingException("BusDetails not Updated"); 
		}
		
		return false;
	}

	
	private int getBookingId() {
	    int bookingId=0;
	    try {
			conn=JdbcUtil.getConnection();
			String query="Select Booking_Id_Seq.NEXTVAL from dual";
			try {
				pst=conn.prepareStatement(query);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{	
					bookingId=rs.getInt(1);
				}
				
				mylogger.info("Booking ID generated"+bookingId);

			} catch (SQLException e) {
				mylogger.error("Booking ID not generated ");
				System.out.println("SQLException while generating BookingID");
				//e.printStackTrace();
			}
		} catch (BookingException e) {
			mylogger.error("Booking ID not generated ");
			System.out.println("BookingException while generating BookingID");
			//e.printStackTrace();
		}   
		return bookingId;
	}
	
	
	public boolean checkBusId(String busId)
	{
		try {
			conn=JdbcUtil.getConnection();
			String query="select busId FROM BusDetails";
			int busidd[]=new int[10];
			int i=0;
			try {
				pst=conn.prepareStatement(query);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					int bus_id=rs.getInt("busId");	
					busidd[i]=bus_id;
					i++;
				}
				int bus_id=Integer.parseInt(busId);
				for(int bid:busidd)
				{
					if(bus_id==bid)
					{
						return true;
					}
				}
			} catch (SQLException e) {
				System.out.println(e);
				throw new BookingException("Bus not present with ID"); 
			}
			
		} catch (BookingException e) {
			System.out.println(e);
		}
		
		return false;
	}
	
	public boolean seatAvailability(String noOfSeats,String busId)
	{
		try {
			conn=JdbcUtil.getConnection();
			String query="select availableSeats FROM BusDetails where busId=?";
			ResultSet rec;
			int seats=0;
			int busid=Integer.parseInt(busId);
			int requiredSeats=Integer.parseInt(noOfSeats);
			try {
				pst=conn.prepareStatement(query);
				pst.setInt(1,busid);
				rec=pst.executeQuery();
				while(rec.next())
				{
					 seats=rec.getInt("availableSeats");
				}
				if(seats>0 && requiredSeats<seats)
				{
					mylogger.info("seats available");
					return true;		
				}
			} catch (SQLException e) {
				mylogger.error("seats not sufficient");
				System.out.println("Sorry No Seats Available");
				throw new BookingException("Sorry No Seats Available"); 
			}
			
		} catch (BookingException e) {
			mylogger.error("seats not sufficient");
			System.out.println("Sorry No Seats Available");
		}
		
		return false;
		
	}



}
