package com.cg.ARS.util;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ARS.exceptions.BookingExceptions;



public class JdbcUtil{

	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
		public static Properties loadProperty()
		{
			Properties prop=new Properties();
			InputStream in=null;
			try {
				in=new FileInputStream("oracle.properties");
				prop.load(in);
				
			    } catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			return prop;
		}
				

		public static Connection getConnection() throws BookingExceptions
		{
			Connection conn=null;
			Properties prop=loadProperty();
			String driver=prop.getProperty("oracle.driver");
			String username=prop.getProperty("oracle.username");
			String url=prop.getProperty("oracle.url");
			String password=prop.getProperty("oracle.password");
		
			try {
				
				Class.forName(driver);                //load driver
				//Class.forName("oracle.jdbc.driver.OracleDriver");         //load driver
				conn=DriverManager.getConnection(url,username,password);
				mylogger.info("Connected to the database");
			} catch (ClassNotFoundException e) {
				System.out.println("ClassNotFoundException in Connection to database");
				//e.printStackTrace();
			}
		      catch (SQLException e) {
		    	  System.out.println("SQLException in Connection to database");
				//e.printStackTrace();
				mylogger.error("Coneection Not Esablished....."+e);
				throw new BookingExceptions("Connection Problem try later");
			}

			return conn;
		}
		

}


