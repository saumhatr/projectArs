package com.capgemini.JunitTest;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;


public class BookTicketTest {
	BusDao busDao;
	BookingBean book;
	private static final Logger mylogger=
			Logger.getLogger(BookTicketTest.class);



	@Before
	public void setUp() throws Exception {
		busDao=new BusDaoImpl();
		book=new BookingBean();
		book.setBookingId(1009);
		book.setBusId(1);
		book.setCustId("D123456");
		book.setNoOfSeat(1);
	}

	@After
	public void tearDown() throws Exception {
		busDao=null;
	}

	@Test
	public void testBookTicket()
	{
		
		try {
		 assertTrue(busDao.bookTicket(book));
			
		} catch (BookingException e) {
			
			e.printStackTrace();
		}
	}

	private void assertTrue(int bookTicket) {
		
		
	}

}
