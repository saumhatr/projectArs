package com.capgemini.JunitTest;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;



public class BusDetailsRetrieveTest {

	BusDao busDao;
	private static final Logger mylogger=
			Logger.getLogger(BusDetailsRetrieveTest.class);

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
		busDao=new BusDaoImpl();
			
	}

	@After
	public void tearDown() throws Exception {
		busDao=null;
	}

	@Test
	public void testShowAll() throws BookingException {
		assertNotNull(busDao.retrieveBusDetails());
		mylogger.info("In test case of BusDao retrieve function working ");
		
	}

}
