package com.capgemini.appl.dao;

import java.util.List;

import javax.swing.text.StyledEditorKit.BoldAction;

import com.capgemini.appl.dto.*;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityDto {

	List<Application> showApplications() throws UniversityAdmissionException;

	boolean addProgram(ProgramsOffered p) throws UniversityAdmissionException;

	List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException;

	boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException;

	boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException;

	boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException;

}
