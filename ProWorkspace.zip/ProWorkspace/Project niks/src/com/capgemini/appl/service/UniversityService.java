package com.capgemini.appl.service;

import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityService {

	List<Application> showApplications() throws UniversityAdmissionException;

	boolean addProgram(ProgramsOffered p) throws UniversityAdmissionException;
	
	List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException;

	boolean acceptOrRejectApplication(Application application) throws UniversityAdmissionException;
	boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException;

	boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException;
	
	
}
